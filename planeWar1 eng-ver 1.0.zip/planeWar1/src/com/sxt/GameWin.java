package com.sxt;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class GameWin extends JFrame {

    Image offScreenImage = null;
    int count = 1;
    int enemyCount = 0;
    int state = 0;
    int MY_WIDTH = 600;
    int MY_HEIGHT = 700;
    Image bg = Toolkit.getDefaultToolkit().getImage("imgs/space4.png");
    Image explode = Toolkit.getDefaultToolkit().getImage("imgs/explode/e6.gif");
    int explode_x = -300;
    int explode_y = 300;
    List<GameObject> objectList = new ArrayList<>();
    List<GameObject> removeList = new ArrayList<>();
    List<ShellObj> shellObjList = new ArrayList<>();
    List<BulletObj> bulletObjList = new ArrayList<>();
    List<EnemyObj> enemyObjList = new ArrayList<>();
    List<ExplodeObj> explodeObjList = new ArrayList<>();
    BgObj bgObj = new BgObj("imgs/space4.png",0,-2000,2,this);
    PlaneObj planeObj = new PlaneObj("imgs/plane2.png",290,550,0,this);
    BossObj bossObj = null;
    public void launch(){
        setVisible(true);
        setSize(MY_WIDTH,MY_HEIGHT);
        setLocationRelativeTo(null);
        setTitle("plane war");

        objectList.add(bgObj);
        objectList.add(planeObj);

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getButton() == 1){
                    state = 1;
                    repaint();
                }
            }
        });
        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                super.keyPressed(e);
               if (e.getKeyCode() == 32){
                    switch (state){
                        case 1:
                            state = 2;
                            break;
                        case 2:
                            state = 1;
                            break;
                    }
               }
            }
        });

        while (true){
            if (state == 1){
                createObj();
                repaint();
            }

            try {
                Thread.sleep(10);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void paint(Graphics g) {
        if(offScreenImage ==null){
            offScreenImage=this.createImage(MY_WIDTH, MY_HEIGHT);
        }
        Graphics gImage= offScreenImage.getGraphics();
        gImage.fillRect(0, 0, MY_WIDTH, MY_HEIGHT);
        if (state == 0){
            gImage.drawImage(bg,0,0,null);
            gImage.setColor(Color.RED);
            gImage.setFont(new Font("Times New Roman",Font.BOLD,50));
            gImage.drawString("click to start",150,300);
        }
        if (state == 1){
            objectList.addAll(explodeObjList);

            for (GameObject object : objectList){
                object.paintSelf(gImage);
            }
            objectList.removeAll(removeList);
        }
        if (state == 3){
            gImage.setColor(Color.red);
            gImage.setFont(new Font("Times New Roman",Font.BOLD,50));
            gImage.drawString("You lose",180,300);
        }
        if (state == 4){
            gImage.setColor(Color.green);
            gImage.setFont(new Font("Times New Roman",Font.BOLD,50));
            gImage.drawString("Game over",150,300);
        }
        gImage.drawImage(explode,explode_x,explode_y,null);
        g.drawImage(offScreenImage, 0, 0, null);
        count++;
        System.out.println("total array length" + objectList.size());
    }

    public void createObj(){
        if (count % 20 == 0){
            shellObjList.add(new ShellObj("imgs/bullet1.png",planeObj.x + 3,planeObj.y - 10,10,this));
            objectList.add(shellObjList.get(shellObjList.size() - 1));
        }
        if (count % 10 == 0 && bossObj != null){
            bulletObjList.add(new BulletObj("imgs/bullet2.png",bossObj.x + 45,bossObj.y + 76,10,this));
            objectList.add(bulletObjList.get(bulletObjList.size() - 1));
        }
        if (count % 15 == 0) {
            enemyObjList.add(new EnemyObj("imgs/enemy2.png",this));
            objectList.add(enemyObjList.get(enemyObjList.size() - 1));
            enemyCount++;
        }
        if (enemyCount > 100){
            if (bossObj == null){
                bossObj = new BossObj("imgs/boss.png",250,30,5,this);
                objectList.add(bossObj);
            }
        }
    }
    public static void main(String[] args) {
        GameWin gameWin = new GameWin();
        gameWin.launch();
    }
}
