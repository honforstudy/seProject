package com.sxt;

import java.awt.*;


public class BgObj extends GameObject {

    int score = 0;

    public BgObj() {
        super();
    }

    public BgObj(String img, GameWin frame) {
        super(img, frame);
    }

    public BgObj(String img, int x, int y, double speed, GameWin frame) {
        super(img, x, y, speed, frame);
    }

    @Override
    public void paintSelf(Graphics g) {
        g.drawImage(img,x,y,null);
        if (y >= 0){
            y = -2000;
        }
        y += speed;

        g.setColor(Color.green);
        g.setFont(new Font("Times New Roman",Font.BOLD,40));
        g.drawString(score + " score",30,100);
    }

    @Override
    public Rectangle getRec() {
        return null;
    }
}
