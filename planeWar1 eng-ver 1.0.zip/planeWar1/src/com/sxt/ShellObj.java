package com.sxt;

import java.awt.*;


public class ShellObj extends GameObject {

    public ShellObj() {
        super();
    }

    public ShellObj(String img, GameWin frame) {
        super(img, frame);
    }

    public ShellObj(String img, int x, int y, double speed, GameWin frame) {
        super(img, x, y, speed, frame);
    }

    @Override
    public void paintSelf(Graphics g) {
        g.drawImage(img,x,y,null);
        y -= speed;
        if (y <= 0){
            this.x = -100;
            this.y = 100;
            this.frame.removeList.add(this);
        }
    }

    @Override
    public Rectangle getRec() {
        return new Rectangle(x,y,15,15);
    }
}
