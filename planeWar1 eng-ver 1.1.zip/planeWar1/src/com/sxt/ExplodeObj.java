package com.sxt;

import java.awt.*;


public class ExplodeObj extends GameObject {

    static Image[] imgs = new Image[16];

    int explodeCount = 0;

    static {
        for (int i = 0; i < 16; i++) {
            imgs[i] = Toolkit.getDefaultToolkit().getImage("imgs/explode/e" +(i + 1)+".gif");
        }
    }

    public ExplodeObj() {
        super();
    }

    public ExplodeObj(int x, int y) {
       this.x = x;
       this.y = y;
    }

    @Override
    public void paintSelf(Graphics g) {
        if (explodeCount < 16){
            g.drawImage(imgs[explodeCount],x,y,null);
            explodeCount++;
        }
    }

    @Override
    public Rectangle getRec() {
        return null;
    }
}
