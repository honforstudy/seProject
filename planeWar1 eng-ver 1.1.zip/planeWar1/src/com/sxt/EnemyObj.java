package com.sxt;

import java.awt.*;


public class EnemyObj extends GameObject{
    int x = (int)(Math.random()*12) * 50;
    int speed = 5;
    public EnemyObj() {
        super();
    }

    public EnemyObj(String img, GameWin frame) {
        super(img, frame);
    }

    public EnemyObj(String img, int x, int y, double speed, GameWin frame) {
        super(img, x, y, speed, frame);
    }

    @Override
    public void paintSelf(Graphics g) {
        g.drawImage(img,x,y,null);
        y += speed;
        if (y > 600){
            this.x = -150;
            this.y = 150;
            this.frame.removeList.add(this);
        }
        if (this.getRec().intersects(this.frame.planeObj.getRec())){
            this.frame.state = 3;
            this.frame.explode_x = this.frame.planeObj.x -11;
            this.frame.explode_y = this.frame.planeObj.y -16;
        }
        for(ShellObj shellObj:this.frame.shellObjList){
            if (this.getRec().intersects(shellObj.getRec())){

                ExplodeObj explodeObj = new ExplodeObj(this.x,this.y);
                this.frame.explodeObjList.add(explodeObj);
                this.frame.removeList.add(explodeObj);
                shellObj.x = -100;
                shellObj.y = 100;
                this.x = -150;
                this.y = 150;
                this.frame.removeList.add(shellObj);
                this.frame.removeList.add(this);
                this.frame.bgObj.score++;
            }
        }
    }

    @Override
    public Rectangle getRec() {
        return new Rectangle(x,y,46,35);
    }
}
