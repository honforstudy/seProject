package com.sxt;

import java.awt.*;

public abstract class GameObject {

    Image img;
    int x;
    int y;
    int width;
    int height;
    double speed;
    GameWin frame;

    public GameObject(){

    }

    public GameObject(String img, GameWin frame) {
        this.img = Toolkit.getDefaultToolkit().getImage(img);
        this.frame = frame;
    }

    public GameObject(String img, int x, int y, double speed, GameWin frame) {
        this.img = Toolkit.getDefaultToolkit().getImage(img);
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.frame = frame;
    }

    public GameObject(String img, int x, int y, int width, int height, double speed, GameWin frame) {
        this.img = Toolkit.getDefaultToolkit().getImage(img);
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.speed = speed;
        this.frame = frame;
    }

    private Image getImg() {
        return img;
    }

    private void setImg(String img) {
        this.img = Toolkit.getDefaultToolkit().getImage(img);
    }

    private int getX() {
        return x;
    }

    private void setX(int x) {
        this.x = x;
    }

    private int getY() {
        return y;
    }

    private void setY(int y) {
        this.y = y;
    }

    private int getWidth() {
        return width;
    }

    private void setWidth(int width) {
        this.width = width;
    }

    private int getHeight() {
        return height;
    }

    private void setHeight(int height) {
        this.height = height;
    }

    private double getSpeed() {
        return speed;
    }

    private void setSpeed(double speed) {
        this.speed = speed;
    }

    private GameWin getFrame() {
        return frame;
    }

    private void setFrame(GameWin frame) {
        this.frame = frame;
    }
    public abstract void paintSelf(Graphics g);

    public abstract Rectangle getRec();
}
